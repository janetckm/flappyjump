#show the score

import pygame 
import random #generate random number

pygame.init()

SCREEN = pygame.display.set_mode((500, 750))

BACKGROUND_IMAGE = pygame.image.load('background.jpg')


# character
BIRD_IMAGE = pygame.image.load('car.png')
bird_x = 50
bird_y = 450
bird_y_change = 0

def display_bird(x, y):
    SCREEN.blit(BIRD_IMAGE, (x, y))
# character end 


OBSTACLE_WIDTH = 70
#height of top obstacle
OBSTACLE_HEIGHT = random.randint(150,450)
OBSTACLE_COLOR = (211, 253, 117)
OBSTACLE_X_CHANGE = -4
#start obstacle from the width of the SCREEN
obstacle_x = 500

def display_obstacle(height):
    # draw from the position (x, y) with size (width, height)
    pygame.draw.rect(SCREEN, OBSTACLE_COLOR, (obstacle_x, 0, OBSTACLE_WIDTH, height))
    bottom_obstacle_height = 535 - height - 150
    pygame.draw.rect(SCREEN, OBSTACLE_COLOR, (obstacle_x, 635, OBSTACLE_WIDTH, -bottom_obstacle_height))
#obstacle end

#Define function: detect collision
def collision_detection (obstacle_x, obstacle_height, bird_y, bottom_obstacle_height):
    if obstacle_x >= 50 and obstacle_x <= (50 + 64):
        if bird_y <= obstacle_height or bird_y >= (bottom_obstacle_height - 64):
            return True
    return False
#end define function: detect collision
    
#define Score Text and set Font
score = 0
SCORE_FONT = pygame.font.Font('freesansbold.ttf', 32)

#define function to display score
def score_display(score):
    display = SCORE_FONT.render(f"Score: {score}", True, (255,255,255))
    SCREEN.blit(display, (10, 10))
#end define for Score

#run the game loop
running = True
while running:
   
  SCREEN.fill((0, 0, 0))
   
  SCREEN.blit(BACKGROUND_IMAGE,(0, 0))
   
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      running = False
    
    #Spacebar control up / down
    if event.type == pygame.KEYDOWN:
      if event.key == pygame.K_SPACE:
         bird_y_change = -6
    if event.type == pygame.KEYUP:
      if event.key == pygame.K_SPACE:
        bird_y_change = 3
    #spacebar control END

  #move bird vertically
  bird_y += bird_y_change
  
  #boundary of screen
  if bird_y <= 0:
    bird_y = 0
  if bird_y >= 550:
    bird_y = 550

  #move obstacle
  obstacle_x += OBSTACLE_X_CHANGE
  if obstacle_x <= -10:
        obstacle_x = 500
        OBSTACLE_HEIGHT = random.randint(200, 400)
        
  #display obstacle
  display_obstacle(OBSTACLE_HEIGHT)
  
  #use the function to detact collisoion 
  collision = collision_detection(obstacle_x, OBSTACLE_HEIGHT, bird_y, OBSTACLE_HEIGHT + 200)
  
  #if collision detection is TRUE, quit game
  if collision:
    pygame.quit()
  
  #display bird 
  display_bird(bird_x, bird_y)
  
  #display score
  score_display(score)
  
  #display game 
  pygame.display.update()
  
  #game loop end

pygame.QUIT()
